import java.io.*;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;


public class ClienteSimples {

    public static void main(String[] args) throws UnknownHostException, IOException {

        // dispara cliente
       ClienteSimples c = new ClienteSimples("127.0.0.1", 12345, "brunocesar@gmail.com" ,"123" ).executa();
    }


    private String email;
    private String senha;
    private String host;
    private int porta;
    private ServidorSimples servidorSimples = new ServidorSimples(12345);

    public ServidorSimples getServidorSimples() {
        return servidorSimples;
    }

    public void setServidorSimples(ServidorSimples servidorSimples) {
        this.servidorSimples = new ServidorSimples(12345);
    }

    public String getHost() {
        return host;
    }

    public void setHost(String host) {
        this.host = host;
    }

    public int getPorta() {
        return porta;
    }

    public void setPorta(int porta) {
        this.porta = porta;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }


    public ClienteSimples (String host, int porta , String email , String senha) {

        this.host = host;
        this.porta = porta;
        this.email=email;
        this.senha=senha;

    }

    public ClienteSimples executa() throws UnknownHostException, IOException {

        Socket cliente = new Socket(this.host, this.porta);
        System.out.println("O cliente se conectou ao servidor!");


        // thread para receber mensagens do servidor

//        Recebedor r = new Recebedor(cliente.getInputStream());
//        new Thread(r).start();

        // lê msgs do teclado e manda pro servidor

        Scanner teclado = new Scanner(System.in);
        PrintStream saida = new PrintStream(cliente.getOutputStream());
        saida.print("Digite seu email:");
        System.out.println("Digite seu email e senha:");
        String email =teclado.nextLine();
        String senha =teclado.nextLine();
        ClienteSimples c = new ClienteSimples("127.0.0.1",cliente.getPort(),email,senha);

        servidorSimples.registrarUsuario(c);


        while (true) {



            saida.println(teclado.nextLine());

        }



    }

}

//
//        Registrar-se no Servidor informando: identificador do usuário (e.g., e-mail), senha
//        , IP e Porta utilizados para receber mensagens de outros clientes;
//        Consultar o servidor, informando o identificador de um outro usuário,
//        para obter o endereço IP e o número de porta associados à instância da aplicação cliente daquele usuário quando desejar estabelecer comunicação com ele(a);
//        Usar TCP para se comunicar com o servidor e UDP para se comunicar com outros clientes.

