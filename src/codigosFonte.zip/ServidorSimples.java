import java.io.IOException;
import java.io.PrintStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;

//class Connection extends Thread {
//    DataInputStream in;
//    DataOutputStream out;
//    Socket clientSocket;
//    public Connection (Socket aClientSocket) {
//        try {
//            clientSocket = aClientSocket;
//            System.out.println("Nova conexão com o cliente " +
//                    clientSocket.getInetAddress().getHostAddress());
//            in = new DataInputStream( clientSocket.getInputStream());
//            out =new DataOutputStream( clientSocket.getOutputStream());
//            this.start();
//        } catch(IOException e)  {System.out.println("Connection:"+e.getMessage());}
//    }
//    public void run(){
//        try {
//            // an echo server
//            String data = in.readUTF();
//            out.writeUTF(data);
//        } catch(EOFException e) {System.out.println("EOF:"+e.getMessage());
//        } catch(IOException e) {System.out.println("IO:"+e.getMessage());}
//        finally{
//            try {clientSocket.close();}catch (IOException e){/*close failed*/}
//        }
//    }
//}

public class ServidorSimples {


    public static void main(String[] args) throws IOException {

            new ServidorSimples(12345).executa();

        }

        private int porta;
        private List<PrintStream> clientes;
        private List<ClienteSimples> lista;

        public ServidorSimples (int porta) {

            this.porta = porta;
            this.lista= new ArrayList<ClienteSimples>();
            this.clientes = new ArrayList<PrintStream>();

        }


        public void executa(){

            ServerSocket servidor = null;

            try {
                    servidor = new ServerSocket(this.porta);
            } catch (IOException e) {
                    e.printStackTrace();
            }

            System.out.println("Porta 12345 aberta!");


            while (true) {

                // aceita um cliente
                Socket cliente = null;
                try {
                    cliente = servidor.accept();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                System.out.println("Nova conexão com o cliente " +

                        cliente.getInetAddress().getHostAddress()

                );
                // adiciona saida do cliente à lista

                PrintStream ps = null;
                try {
                    ps = new PrintStream(cliente.getOutputStream());
                } catch (IOException e) {
                    e.printStackTrace();
                }


                clientes.add(ps);

                // cria tratador de cliente numa nova thread
                TrataCliente tc = null;
                try {
                    tc = new TrataCliente(cliente.getInputStream(), this);
                } catch (IOException e) {
                    e.printStackTrace();
                }
                new Thread(tc).start();

            }

        }


        public void distribuiMensagem(String msg) {

            // envia msg para todo mundo

            for (PrintStream cliente : this.clientes) {

                cliente.println(msg);

            }

        }

        public void registrarUsuario(ClienteSimples c) {

            lista.add(c);

        }

        public boolean autenticarUsuario(String email , String senha) {

            for (int i=0 ; i< lista.size() ;i++) {

                if(lista.get(i).getEmail().equals(email) && lista.get(i).getSenha().equals(senha)){

                    return true;
                }

            }

            return false;
        }

        public Object[] IpPorta(String email){

            Object[] s = new Object[2];
            for (int i=0 ; i< lista.size() ;i++) {

                if(lista.get(i).getEmail().equals(email)){

                    s[0]=lista.get(i).getHost();
                    s[1]=lista.get(i).getPorta();

                    return s;
                }

            }

            return null;

        }

}
