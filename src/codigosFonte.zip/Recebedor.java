//import java.io.InputStream;
//import java.io.PrintStream;
//import java.util.Scanner;
//
//public class Recebedor implements Runnable {
//
//    private InputStream servidor;
//    public Recebedor(InputStream servidor) {
//
//        this.servidor = servidor;
//
//    }
//    public void run() {
//
//        // recebe msgs do servidor e imprime na tela
//        Scanner s = new Scanner(this.servidor);
//        PrintStream saida = new PrintStream(cliente.getOutputStream());
//        while (true) {
//
//            String email = s.nextLine();
//            System.out.println(s.nextLine());
//
//        }
//
//    }
//
//}
